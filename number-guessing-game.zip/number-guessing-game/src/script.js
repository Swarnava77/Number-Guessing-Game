var guess = Math.floor(Math.random()*100)+1; //System's guess

function response()
{
  var n = document.getElementById('in').value;
  if(n == guess)
    document.getElementById('out').innerHTML = "Congrats! Got it correctly!";
  else if(n > guess)
    document.getElementById('out').innerHTML = "Guess a smaller value";
  else
    document.getElementById('out').innerHTML = "Guess a greater value";
}